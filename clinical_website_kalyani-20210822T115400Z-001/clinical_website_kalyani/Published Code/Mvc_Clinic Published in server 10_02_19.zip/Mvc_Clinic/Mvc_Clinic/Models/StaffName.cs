﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_Clinic.Models
{
    public class StaffName
    {
      
        public string StaffNames { get; set; }

    }
}